const express = require('express');
const router = express.Router();
const db = require('../db');

// RUTA PARA GUARDAR
router.post('/guardar', async (req, res) => {
    console.log("📥 Guardando ruta:", req.body);

    // 1. Recibimos también 'descripcion' (si la envías desde el front)
    const { titulo, descripcion, coordenadas, usuario_id } = req.body;

    if (!titulo || !coordenadas || !usuario_id) {
        return res.status(400).json({ error: "Faltan datos obligatorios" });
    }

    try {
        const coordsJSON = JSON.stringify(coordenadas);
        
        // 2. Insertamos incluyendo la descripción
        const sql = 'INSERT INTO routes (title, description, coordinates, user_id) VALUES (?, ?, ?, ?)';
        const [result] = await db.query(sql, [titulo, descripcion, coordsJSON, usuario_id]);

        res.json({ msg: "Ruta guardada", id: result.insertId });

    } catch (error) {
        console.error("🔥 Error SQL:", error.sqlMessage);
        res.status(500).json({ error: "Error de base de datos: " + error.sqlMessage });
    }
});

// RUTA PARA LEER
router.get('/:usuario_id', async (req, res) => {
    try {
        const [rutas] = await db.query('SELECT * FROM routes WHERE user_id = ?', [req.params.usuario_id]);
        res.json(rutas);
    } catch (error) {
        res.status(500).json({ error: "Error al leer rutas" });
    }
});

module.exports = router;